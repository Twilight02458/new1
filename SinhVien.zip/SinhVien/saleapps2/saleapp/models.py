from saleapp import db
from sqlalchemy import Column, Integer, String

class Category (db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=True)

    def __str__(self):
        return self.name



